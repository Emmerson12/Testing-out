import React from "react";

export default function NewListings() {
  return <div>

    
  </div>;
}
